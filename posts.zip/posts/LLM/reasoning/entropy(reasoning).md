---
title: entropy(reasoning)
date: 2025-07-06
lastmod: 2025-07-06
categories:
  - ""
  - LLM
  - reasoning
tags:
  - LLM
  - reasoning
author: vllbc
mathjax: true
markup: pdc
todo: true
---
## 熵坍塌

### [UloRL：An Ultra-Long Output Reinforcement Learning Approach for Advancing Large Language Models’ Reasoning Abilities](../../reading/Reasoning/UloRL：An%20Ultra-Long%20Output%20Reinforcement%20Learning%20Approach%20for%20Advancing%20Large%20Language%20Models’%20Reasoning%20Abilities.md)

### [ProRL：Prolonged Reinforcement Learning Expands Reasoning Boundaries in Large Language Models](../../reading/Reasoning/ProRL：Prolonged%20Reinforcement%20Learning%20Expands%20Reasoning%20Boundaries%20in%20Large%20Language%20Models.md)

### [BEYOND PASS@1：SELF-PLAY WITH VARIATIONAL PROBLEM SYNTHESIS SUSTAINS RLVR](../../reading/Reasoning/BEYOND%20PASS@1：SELF-PLAY%20WITH%20VARIATIONAL%20PROBLEM%20SYNTHESIS%20SUSTAINS%20RLVR.md)

### Skywork Open Reasoner 1 Technical Report
## 利用熵

### [Beyond the 80 20 Rule：High-Entropy Minority Tokens Drive Effective Reinforcement Learning for LLM Reasoning](../../reading/Reasoning/Beyond%20the%2080%2020%20Rule：High-Entropy%20Minority%20Tokens%20Drive%20Effective%20Reinforcement%20Learning%20for%20LLM%20Reasoning.md)

### [First Return, Entropy-Eliciting Explore](../../reading/Reasoning/First%20Return,%20Entropy-Eliciting%20Explore.md)

### [AGENTIC REINFORCED POLICY OPTIMIZATION](../../reading/Agent/AGENTIC%20REINFORCED%20POLICY%20OPTIMIZATION.md)

### [CURE：Critical-Token-Guided Re-concatenation for Entropy-collapse Prevention](../../reading/Reasoning/CURE：Critical-Token-Guided%20Re-concatenation%20for%20Entropy-collapse%20Prevention.md)

### [ETTRL：BALANCING EXPLORATION AND EXPLOITATION IN LLM TEST-TIME REINFORCEMENT LEARNING VIA ENTROPY MECHANISM](../../reading/Reasoning/ETTRL：BALANCING%20EXPLORATION%20AND%20EXPLOITATION%20IN%20LLM%20TEST-TIME%20REINFORCEMENT%20LEARNING%20VIA%20ENTROPY%20MECHANISM.md)

### [GTPO and GRPO-S：Token and Sequence-Level Reward Shaping with Policy Entropy](../../reading/Reasoning/GTPO%20and%20GRPO-S：Token%20and%20Sequence-Level%20Reward%20Shaping%20with%20Policy%20Entropy.md)

### [EDGE-GRPO：Entropy-Driven GRPO with Guided Error Correction for Advantage Diversity](../../reading/Reasoning/EDGE-GRPO：Entropy-Driven%20GRPO%20with%20Guided%20Error%20Correction%20for%20Advantage%20Diversity.md)
### [GTPO：Trajectory-Based Policy Optimization in Large Language Models](../../reading/Reasoning/GTPO：Trajectory-Based%20Policy%20Optimization%20in%20Large%20Language%20Models.md)

### [SSRL：SELF-SEARCH REINFORCEMENT LEARNING](../../reading/Agent/SSRL：SELF-SEARCH%20REINFORCEMENT%20LEARNING.md)
利用熵来判断是依赖自己的内部知识还是依赖于外部工具。

## 如何缓解熵坍塌？
1. clip-higher
2. on-policy
3. entropy loss
4. 
## 参考

[小作坊的强化之路](https://zhuanlan.zhihu.com/p/1925691663654850602)