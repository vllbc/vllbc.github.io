---
title: CPU offloading
date: 2025-07-10
lastmod: 2025-07-10
categories:
  - ""
  - LLM
  - infra
tags:
  - LLM
  - infra
author: vllbc
mathjax: true
markup: pdc
todo: true
---
**CPU 卸载**允许我们将一些状态传输到 CPU，因此我们不必将所有内容都保存在 GPU RAM 中。虽然 CPU作比 GPU作慢，但将不常访问的数据移动到 CPU 内存可以帮助我们保持在 GPU 内存限制范围内。