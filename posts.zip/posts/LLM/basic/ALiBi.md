---
title: ALiBi
date: 2025-07-29
lastmod: 2025-07-29
Categories:
  - basic
  - LLM
tags:
  - LLM
  - basic
Author: vllbc
Mathjax: true
Markup: pdc
Todo: false
---
在softmax的结果后添加一个静态的不可学习的偏置项。
![image.png](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/20250729142636.png)
q1和k1之间的距离是0，所以对应位置就是0  
 q2和k1之间的距离是「相对位置偏移为“**k的索引**”1」 - 「q的索引2」，得到1-2 = -1，就对应到了中间矩阵的取值为-1了  
以此类推，相对距离矩阵的中间对角线上都是0，然后左下角的取值都是对应的「k的索引」-「q的索引」了