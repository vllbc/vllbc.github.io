---
title: fsdp
date: 2025-07-06
lastmod: 2025-07-06
categories:
  - ""
  - LLM
  - 大模型分布式
tags:
  - LLM
  - 大模型分布式
author: vllbc
mathjax: true
markup: pdc
todo: true
---


## 参考

[RL 系统深思：FSDP 训练后端](https://zhuanlan.zhihu.com/p/1929115059113693341)

[PyTorch FSDP 设计解读](https://zhuanlan.zhihu.com/p/694288870)