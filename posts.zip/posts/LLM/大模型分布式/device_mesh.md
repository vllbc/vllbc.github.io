---
title: device_mesh
date: 2025-07-26
lastmod: 2025-07-26
Categories:
  - 大模型分布式
  - LLM
tags:
  - LLM
  - 大模型分布式
Author: vllbc
Mathjax: true
Markup: pdc
Todo: true
---

## verl中的device_mesh

verl中有3个device_mesh，分别是：
- 训练用的FSDP mesh（通常是一维）
- 推理用的rollout mesh（包含tp维度）
- Ulysses序列并行的mesh（dp×sp）

## fsdp mesh

## rollout mesh

## ulysses mesh