---
title: "TextRank"
date: 2021-05-20
lastmod: 2023-03-24
categories: ['NLP']
tags: ['NLP', 'TextRank']
author: "vllbc"
mathjax: true
markup: pdc

---


参考：[https://blog.csdn.net/asialee_bird/article/details/96894533](https://blog.csdn.net/asialee_bird/article/details/96894533)

**TextRank算法**是一种基于图的用于关键词抽取和文档摘要的排序算法，由谷歌的网页重要性排序算法PageRank算法改进而来，它利用一篇文档内部的词语间的共现信息(语义)便可以抽取关键词，它能够从一个给定的文本中抽取出该文本的关键词、关键词组，并使用抽取式的自动文摘方法抽取出该文本的关键句。

## PageRank算法

**PageRank算法**通过计算网页链接的数量和质量来粗略估计网页的重要性，算法创立之初即应用在谷歌的搜索引擎中，对网页进行排名。 

**PageRank算法的核心思想如下：**

**（1）链接数量**：如果一个网页被越多的其他网页链接，说明这个网页越重要，即该网页的PR值（PageRank值）会相对较高；

**（2）链接质量**：如果一个网页被一个越高权值的网页链接，也能表明这个网页越重要，即一个PR值很高的网页链接到一个其他网页，那么被链接到的网页的PR值会相应地因此而提高。

![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/PageRank.png)

## TextRank算法

**TextRank算法的基本思想**是将文档看作一个词的网络，该网络中的链接表示词与词之间的语义关系。

![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/TextRank.png)



**TextRank算法主要包括**：关键词抽取、关键短语抽取、关键句抽取。

### （1）关键词抽取（keyword extraction）

关键词抽取是指从文本中确定一些能够描述文档含义的术语的过程。对关键词抽取而言，用于构建顶点集的文本单元可以是句子中的一个或多个字；根据这些字之间的关系（比如：在一个框中同时出现）构建边。根据任务的需要，可以使用语法过滤器（syntactic filters）对顶点集进行优化。语法过滤器的主要作用是将某一类或者某几类词性的字过滤出来作为顶点集。

### （2）关键短语抽取（keyphrase extration）

关键词抽取结束后，我们可以得到的N个关键词，在原始文本中相邻的关键词构成关键短语。因此，从get_keyphrases函数的源码中我们可以看到，它先调用get_keywords抽取关键词，然后分析关键词是否存在相邻的情况，最后确定哪些是关键短语。

### （3）关键句抽取（sentence extraction）

句子抽取任务主要针对的是自动摘要这个场景，将每一个sentence作为一个顶点，根据两个句子之间的内容重复程度来计算他们之间的“相似度”，以这个相似度作为联系，由于不同句子之间相似度大小不一致，在这个场景下构建的是以相似度大小作为edge权重的有权图。