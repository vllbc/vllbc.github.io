---
title: world_model
date: 2025-06-30
lastmod: 2025-06-30
categories:
  - ""
  - NLP
  - agent
  - world-model
tags:
  - NLP
  - agent
  - world-model
author: vllbc
mathjax: true
markup: pdc
todo: true
---
我理解的agent中的world model即可以预测采取某个action之后state的变化，这样做的好处是可以降低试错带来的时间成本或者是其它潜在的成本、风险。

目前agent中常用的模块为reflexion，即反思模块。作用是评价行动轨迹的结果是成功还是失败，如果评估为失败，则接受失败的轨迹和评估结果，生成一段失败总结文本。

这当然是可行的，但问题是这需要不断试错才有可能纠错从而执行正确的action，这就会造成时间成本，甚至如果agent负责的是一个购物任务，错误的action甚至有可能是下单错误的商品。

所以我认为world model的作用就是预测action之后state会如何变化，这相当于走一步，看一步，来避免出错。

reflexion是必要的，这是对整个轨迹的评估，如果评估结果为失败的话，还是要进行反思，与world model结合的作用是降低评估失败的概率，使试错的次数降低。我认为这在实际应用当中是有必要的，试错的时间成本要远远大于每一步调用world model所带来的开销。