---
title: dynamic_bsz
date: 2025-07-27
lastmod: 2025-07-27
Categories:
  - verl
  - coding
tags:
  - coding
  - verl
Author: vllbc
Mathjax: true
Markup: pdc
Todo: true
---
[1 tool called]

让我进一步查看相关的辅助函数，特别是 `rearrange_micro_batches` 函数，以更好地理解动态批处理的逻辑：

[1 tool called]

现在让我查看一下 ulysses 序列并行相关的代码，以更好地理解序列并行的处理逻辑：

[1 tool called]

现在我已经阅读了所有相关的源码，让我为你整理这些参数之间的关系和作用顺序。

## 序列并行、use_dynamic_bsz、remove_padding、ppo_mini_batch_size、ppo_micro_batch_size_per_gpu 关系总结

### 1. 参数定义与作用

| 参数 | 作用 |
|------|------|
| **ulysses_sequence_parallel_size** | Ulysses 序列并行大小，将序列切分到多个 GPU 上并行计算 |
| **use_dynamic_bsz** | 动态批处理，根据 token 总数动态划分 micro batch，平衡各 batch 的计算量 |
| **use_remove_padding** | 移除 padding，将多个序列的有效 token 拼接成一个连续序列，配合 flash_attn_varlen 使用 |
| **ppo_mini_batch_size** | PPO 训练时每个 mini batch 的样本数 |
| **ppo_micro_batch_size_per_gpu** | 每个 GPU 上的 micro batch 大小（梯度累积的基本单位） |

---

### 2. 数据流与作用顺序

#### 2.1 `compute_log_prob` 阶段（推理/计算 log prob）

```
输入数据 (DataProto)
       │
       ▼
┌──────────────────────────────────────────────────────────┐
│  Step 1: 划分 Micro Batches                               │
│  ├─ if use_dynamic_bsz:                                  │
│  │    使用 rearrange_micro_batches() 按 token 总数动态划分  │
│  │    max_token_len = meta_info["max_token_len"] * sp_size│
│  │    返回重排后的 micro_batches 和 indices                │
│  └─ else:                                                │
│       按固定 micro_batch_size 均匀切分                     │
└──────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────┐
│  Step 2: 对每个 Micro Batch 进行前向计算                   │
│  └─ _forward_micro_batch()                               │
│      ├─ if use_remove_padding:                           │
│      │    ├─ unpad_input(): 移除 padding，得到连续 token   │
│      │    ├─ if use_ulysses_sp:                          │
│      │    │    ├─ ulysses_pad(): 填充到 sp_size 整数倍     │
│      │    │    └─ ulysses_pad_and_slice_inputs():        │
│      │    │        切分序列到各 SP rank                    │
│      │    ├─ 模型前向 (flash_attn_varlen)                 │
│      │    ├─ if use_ulysses_sp:                          │
│      │    │    └─ gather_outpus_and_unpad(): 聚合并去除填充│
│      │    └─ pad_input(): 恢复原始 batch 形状              │
│      └─ else (不使用 remove_padding):                     │
│           └─ 标准前向计算                                  │
└──────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────┐
│  Step 3: 合并结果                                         │
│  ├─ concat 所有 micro batch 的 log_probs                  │
│  └─ if use_dynamic_bsz:                                  │
│       使用 get_reverse_idx() 恢复原始顺序                  │
└──────────────────────────────────────────────────────────┘
```

#### 2.2 `update_policy` 阶段（PPO 训练）

```
输入数据 (DataProto, batch_size = N)
       │
       ▼
┌──────────────────────────────────────────────────────────┐
│  Step 1: 划分 Mini Batches                                │
│  num_mini_batches = N / ppo_mini_batch_size              │
│  dataloader = data.chunk(num_mini_batches)               │
└──────────────────────────────────────────────────────────┘
       │
       ▼
  for epoch in ppo_epochs:
    for mini_batch in dataloader:
       │
       ▼
┌──────────────────────────────────────────────────────────┐
│  Step 2: 划分 Micro Batches (梯度累积)                     │
│  ├─ if use_dynamic_bsz:                                  │
│  │    使用 rearrange_micro_batches() 按 token 总数动态划分  │
│  │    max_token_len = ppo_max_token_len_per_gpu * sp_size │
│  └─ else:                                                │
│       gradient_accumulation = ppo_mini_batch_size /      │
│                               ppo_micro_batch_size_per_gpu│
│       micro_batches = mini_batch.split(                  │
│                         ppo_micro_batch_size_per_gpu)    │
└──────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────┐
│  Step 3: 梯度累积                                         │
│  optimizer.zero_grad()                                   │
│  for micro_batch in micro_batches:                       │
│      ├─ _forward_micro_batch() (同上，含 SP 和 rmpad)     │
│      ├─ 计算 policy_loss                                 │
│      ├─ if use_dynamic_bsz:                              │
│      │    loss = policy_loss * (len(data) /              │
│      │                          ppo_mini_batch_size)     │
│      └─ else:                                            │
│           loss = policy_loss / gradient_accumulation     │
│      loss.backward()                                     │
│  optimizer.step()                                        │
└──────────────────────────────────────────────────────────┘
```

---

### 3. 关键关系图

```
                    ┌─────────────────────────────────────┐
                    │         Total Batch (N samples)      │
                    └─────────────────────────────────────┘
                                      │
                    ┌─────────────────┴─────────────────┐
                    │     ppo_mini_batch_size 划分       │
                    │   (PPO 每次更新使用的样本数)         │
                    └─────────────────┬─────────────────┘
                                      │
              ┌───────────────────────┼───────────────────────┐
              │                       │                       │
        Mini Batch 1            Mini Batch 2            Mini Batch K
              │                       │                       │
              └───────────────────────┼───────────────────────┘
                                      │
                    ┌─────────────────┴─────────────────┐
                    │  use_dynamic_bsz ?                 │
                    └─────────────────┬─────────────────┘
                           ┌──────────┴──────────┐
                           │                     │
                      Yes (动态)             No (固定)
                           │                     │
              ┌────────────┴────────────┐   ┌────┴────┐
              │ rearrange_micro_batches │   │  split  │
              │ 按 max_token_len 划分    │   │ 按固定  │
              │ (平衡各 batch token 数)  │   │ micro   │
              │                         │   │ batch   │
              │ max_token_len =         │   │ size    │
              │ ppo_max_token_len_per_gpu│   │         │
              │ * ulysses_sp_size       │   │         │
              └────────────┬────────────┘   └────┬────┘
                           │                     │
                           └──────────┬──────────┘
                                      │
                              Micro Batches
                                      │
                    ┌─────────────────┴─────────────────┐
                    │  use_remove_padding ?              │
                    └─────────────────┬─────────────────┘
                           ┌──────────┴──────────┐
                           │                     │
                      Yes (移除)             No (保留)
                           │                     │
              ┌────────────┴────────────┐        │
              │ unpad_input()           │        │
              │ 移除 padding，拼接有效   │        │
              │ token 成连续序列         │        │
              └────────────┬────────────┘        │
                           │                     │
                    ┌──────┴──────┐              │
                    │ ulysses_sp? │              │
                    └──────┬──────┘              │
                    ┌──────┴──────┐              │
                    │             │              │
                Yes (SP)      No (单卡)          │
                    │             │              │
           ┌────────┴────────┐    │              │
           │ ulysses_pad +   │    │              │
           │ slice_inputs    │    │              │
           │ 切分序列到各 rank│    │              │
           └────────┬────────┘    │              │
                    │             │              │
                    └──────┬──────┘              │
                           │                     │
                           └──────────┬──────────┘
                                      │
                              Model Forward
                                      │
                    ┌─────────────────┴─────────────────┐
                    │  后处理: gather + unpad + revert   │
                    └─────────────────────────────────────┘
```

---

### 4. 参数配合使用的典型场景

| 场景 | use_dynamic_bsz | use_remove_padding | ulysses_sp | 说明 |
|------|-----------------|-------------------|------------|------|
| **基础训练** | ❌ | ❌ | ❌ | 固定 batch size，标准 attention |
| **长序列优化** | ❌ | ✅ | ❌ | 移除 padding 减少无效计算 |
| **负载均衡** | ✅ | ❌ | ❌ | 动态划分 batch 平衡各 GPU 计算量 |
| **长序列 + 负载均衡** | ✅ | ✅ | ❌ | 推荐配置，效率最高 |
| **超长序列** | ✅ | ✅ | ✅ | 序列并行支持超长序列训练 |

---

### 5. 关键代码逻辑总结

#### 5.1 动态批处理 (`use_dynamic_bsz`)
```python
# 核心函数: rearrange_micro_batches()
# 使用 Karmarkar-Karp 算法平衡各 micro batch 的 token 总数
max_token_len = ppo_max_token_len_per_gpu * ulysses_sequence_parallel_size
micro_batches, indices = rearrange_micro_batches(batch, max_token_len)

# Loss 缩放 (保证梯度正确)
loss = policy_loss * (len(data) / ppo_mini_batch_size)
```

#### 5.2 移除 Padding (`use_remove_padding`)
```python
# 移除 padding
input_ids_rmpad, indices, cu_seqlens, *_ = unpad_input(input_ids.unsqueeze(-1), attention_mask)

# 模型使用 flash_attn_varlen 进行计算
output = self.actor_module(input_ids=input_ids_rmpad, attention_mask=None, ...)

# 恢复原始形状
full_log_probs = pad_input(hidden_states=log_probs.unsqueeze(-1), indices=indices, batch=batch_size, seqlen=seqlen)
```

#### 5.3 序列并行 (`ulysses_sequence_parallel_size > 1`)
```python
# 填充并切分输入
input_ids_rmpad, position_ids_rmpad, pad_size = ulysses_pad_and_slice_inputs(
    input_ids_rmpad, position_ids_rmpad, sp_size=self.ulysses_sequence_parallel_size
)

# 模型前向后聚合结果
log_probs = gather_outpus_and_unpad(log_probs, gather_dim=0, unpad_dim=0, padding_size=pad_size)
```

#### 5.4 梯度累积关系
```python
# 固定 batch size 模式
gradient_accumulation = ppo_mini_batch_size // ppo_micro_batch_size_per_gpu
loss = policy_loss / gradient_accumulation

# 动态 batch size 模式
loss = policy_loss * (len(data) / ppo_mini_batch_size)  # 按实际样本数比例缩放
```

---

### 6. 总结

1. **层级关系**: `Total Batch` → `Mini Batch` (ppo_mini_batch_size) → `Micro Batch` (ppo_micro_batch_size_per_gpu 或动态划分)

2. **use_dynamic_bsz** 影响 micro batch 的划分方式，使用 token 总数而非样本数来平衡负载

3. **use_remove_padding** 影响单个 micro batch 内部的计算方式，移除无效 padding 提升效率

4. **ulysses_sequence_parallel** 影响序列维度的并行计算，需要配合 `max_token_len * sp_size` 来正确划分

5. **三者可以组合使用**，推荐配置是 `use_dynamic_bsz=True` + `use_remove_padding=True`，在处理变长序列时效率最高