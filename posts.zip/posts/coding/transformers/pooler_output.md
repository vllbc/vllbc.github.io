---
title: pooler_output
date: 2024-01-15
lastmod: 2024-01-15
categories:
  - 库学习
  - transformers
tags:
  - 库学习
  - transformers
  - pooler_output
author: vllbc
mathjax: true
markup: pdc
---
