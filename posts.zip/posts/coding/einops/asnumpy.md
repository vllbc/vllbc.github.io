---
title: asnumpy
date: 2025-01-08
lastmod: 2025-01-08
categories:
  - ""
  - einops
tags:
  - einops
author: vllbc
mathjax: true
markup: pdc
---
>Convert a tensor of an imperative framework (i.e. numpy/cupy/torch/jax/etc.) to `numpy.ndarray`

![image.png](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/20250108154828.png)
