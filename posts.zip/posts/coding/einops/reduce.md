---
title: reduce
date: 2025-01-11
lastmod: 2025-01-11
categories:
  - ""
  - einops
tags:
  - einops
author: vllbc
mathjax: true
markup: pdc
---
>einops.reduce combines rearrangement and reduction using reader-friendly notation.

reduce会使维度减少。
![image.png](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/20250111210806.png)
![image.png](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/20250111210816.png)
