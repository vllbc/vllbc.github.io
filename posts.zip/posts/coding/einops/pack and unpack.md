---
title: pack and unpack
date: 2025-01-11
lastmod: 2025-01-11
categories:
  - einops
tags:
  - einops
author: vllbc
mathjax: true
markup: pdc
---
## pack
>Packs several tensors into one. See einops tutorial for introduction into packing (and how it replaces stack and concatenation).


![image.png](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/20250111213846.png)
##  unpack
>Unpacks a single tensor into several by splitting over a selected axes. See einops tutorial for introduction into packing (and how it replaces stack and concatenation).

![image.png](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/20250111214147.png)
