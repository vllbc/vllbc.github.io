---
title: rearrange
date: 2025-01-11
lastmod: 2025-01-11
categories:
  - ""
  - einops
tags:
  - einops
author: vllbc
mathjax: true
markup: pdc
---
>einops.rearrange is a reader-friendly smart element reordering for multidimensional tensors. This operation includes functionality of transpose (axes permutation), reshape (view), squeeze, unsqueeze, stack, concatenate and other operations.

代替reshape，给维度命名。可以用...代表不想动的维度。
![image.png](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/20250111210502.png)
![image.png](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/20250111210626.png)
