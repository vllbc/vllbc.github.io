---
title: nano-vllm阅读笔记
date: 2026-01-07
lastmod: 2026-01-07
Categories:
  - vllm
  - coding
Tags:
  - coding
  - vllm
Author: vllbc
Mathjax: true
Markup: pdc
Todo: true
---

# BlockManager 详解

`BlockManager` 是 nano-vllm 中实现 **PagedAttention** 的核心组件，负责管理 KV Cache 的内存分配。

## 1. 核心概念：PagedAttention

在 LLM 推理中，KV Cache 是存储注意力机制中 Key 和 Value 的缓存。传统方式为每个序列预分配连续内存，造成大量浪费。**PagedAttention** 借鉴操作系统的虚拟内存分页思想：

- 将 KV Cache 划分为固定大小的 **Block**（页）
- 序列不再需要连续内存，而是通过 **Block Table**（页表）映射到物理块
- 支持 **Prefix Caching**：相同前缀的序列可以共享 KV Cache

## 2. 数据结构

### Block 类

```8:24:nanovllm/engine/block_manager.py
class Block:

    def __init__(self, block_id):
        self.block_id = block_id
        self.ref_count = 0
        self.hash = -1
        self.token_ids = []

    def update(self, hash: int, token_ids: list[int]):
        self.hash = hash
        self.token_ids = token_ids

    def reset(self):
        self.ref_count = 1
        self.hash = -1
        self.token_ids = []
```

| 属性 | 说明 |
|------|------|
| `block_id` | 物理块的唯一标识 |
| `ref_count` | 引用计数，支持多序列共享同一块 |
| `hash` | 块内容的哈希值，用于 Prefix Caching |
| `token_ids` | 该块存储的 token 序列 |

### BlockManager 类

```27:36:nanovllm/engine/block_manager.py
class BlockManager:

    def __init__(self, num_blocks: int, block_size: int):
        self.block_size = block_size
        self.blocks: list[Block] = [Block(i) for i in range(num_blocks)]
        self.hash_to_block_id: dict[int, int] = dict()
        self.free_block_ids: deque[int] = deque(range(num_blocks))
        self.used_block_ids: set[int] = set()
```

| 属性 | 说明 |
|------|------|
| `block_size` | 每个块的大小（默认 256 tokens） |
| `blocks` | 所有物理块的列表 |
| `hash_to_block_id` | 哈希值到块 ID 的映射（Prefix Caching 核心） |
| `free_block_ids` | 空闲块队列 |
| `used_block_ids` | 已使用块集合 |

## 3. 核心方法详解

### 3.1 哈希计算 - Prefix Caching 的基础

```38:44:nanovllm/engine/block_manager.py
    @classmethod
    def compute_hash(cls, token_ids: list[int], prefix: int = -1):
        h = xxhash.xxh64()
        if prefix != -1:
            h.update(prefix.to_bytes(8, "little"))
        h.update(np.array(token_ids).tobytes())
        return h.intdigest()
```

使用 **xxhash** 计算块的哈希值，关键设计：
- 哈希值不仅包含当前块的 token，还包含**前一个块的哈希值**（`prefix`）
- 这形成了一个**哈希链**，确保只有完全相同前缀的序列才能共享块

### 3.2 块分配 - `allocate()`

```58:81:nanovllm/engine/block_manager.py
    def allocate(self, seq: Sequence):
        assert not seq.block_table
        h = -1
        cache_miss = False
        for i in range(seq.num_blocks):
            token_ids = seq.block(i)
            h = self.compute_hash(token_ids, h) if len(token_ids) == self.block_size else -1
            block_id = self.hash_to_block_id.get(h, -1)
            if block_id == -1 or self.blocks[block_id].token_ids != token_ids:
                cache_miss = True
            if cache_miss:
                block_id = self.free_block_ids[0]
                block = self._allocate_block(block_id)
            else:
                seq.num_cached_tokens += self.block_size
                if block_id in self.used_block_ids:
                    block = self.blocks[block_id]
                    block.ref_count += 1
                else:
                    block = self._allocate_block(block_id)
            if h != -1:
                block.update(h, token_ids)
                self.hash_to_block_id[h] = block_id
            seq.block_table.append(block_id)
```

**分配流程**：

```
┌─────────────────────────────────────────────────────────────┐
│  对于序列的每个块 i:                                          │
│  ┌─────────────────────────────────────────────────────────┐│
│  │ 1. 计算当前块的哈希值 h（包含前缀哈希）                    ││
│  │ 2. 查找 hash_to_block_id 是否有匹配                      ││
│  │    ├─ Cache Hit: 复用已有块，ref_count++                 ││
│  │    │             seq.num_cached_tokens += block_size     ││
│  │    └─ Cache Miss: 分配新块                               ││
│  │ 3. 将 block_id 加入 seq.block_table                      ││
│  └─────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────┘
```

**关键点**：
- 只有**完整填满**的块（`len(token_ids) == block_size`）才计算哈希
- 一旦发生 cache miss，后续所有块都必须重新分配（哈希链断裂）

### 3.3 块释放 - `deallocate()`

```83:91:nanovllm/engine/block_manager.py
    def deallocate(self, seq: Sequence):
        for block_id in reversed(seq.block_table):
            block = self.blocks[block_id]
            block.ref_count -= 1
            if block.ref_count == 0:
                self._deallocate_block(block_id)
        seq.num_cached_tokens = 0
        seq.block_table.clear()
```

- 逆序遍历释放块（从后往前）
- 只有当 `ref_count == 0` 时才真正释放
- 共享块在所有引用者释放后才回收

### 3.4 Decode 阶段追加 - `can_append()` 和 `may_append()`

```93:113:nanovllm/engine/block_manager.py
    def can_append(self, seq: Sequence) -> bool:
        return len(self.free_block_ids) >= (len(seq) % self.block_size == 1)

    def may_append(self, seq: Sequence):
        block_table = seq.block_table
        last_block = self.blocks[block_table[-1]]
        if len(seq) % self.block_size == 1:
            assert last_block.hash != -1
            block_id = self.free_block_ids[0]
            self._allocate_block(block_id)
            block_table.append(block_id)
        elif len(seq) % self.block_size == 0:
            assert last_block.hash == -1
            token_ids = seq.block(seq.num_blocks-1)
            prefix = self.blocks[block_table[-2]].hash if len(block_table) > 1 else -1
            h = self.compute_hash(token_ids, prefix)
            last_block.update(h, token_ids)
            self.hash_to_block_id[h] = last_block.block_id
        else:
            assert last_block.hash == -1
```

Decode 阶段每次生成一个 token，需要处理三种情况：

| 条件 | 含义 | 操作 |
|------|------|------|
| `len(seq) % block_size == 1` | 刚进入新块 | 分配新块 |
| `len(seq) % block_size == 0` | 刚填满一个块 | 计算哈希，注册到缓存 |
| 其他 | 块未满 | 无需操作 |

## 4. 在 Scheduler 中的应用

```1:72:nanovllm/engine/scheduler.py
// ... Scheduler 使用 BlockManager ...
```

### 4.1 Prefill 阶段

```28:40:nanovllm/engine/scheduler.py
        # prefill
        scheduled_seqs = []
        num_seqs = 0
        num_batched_tokens = 0
        while self.waiting and num_seqs < self.max_num_seqs:
            seq = self.waiting[0]
            if num_batched_tokens + len(seq) > self.max_num_batched_tokens or not self.block_manager.can_allocate(seq):
                break
            num_seqs += 1
            self.block_manager.allocate(seq)
            // ...
```

- 检查 `can_allocate()` 确保有足够空闲块
- 调用 `allocate()` 分配块并尝试复用 Prefix Cache

### 4.2 Decode 阶段

```42:56:nanovllm/engine/scheduler.py
        # decode
        while self.running and num_seqs < self.max_num_seqs:
            seq = self.running.popleft()
            while not self.block_manager.can_append(seq):
                if self.running:
                    self.preempt(self.running.pop())
                else:
                    self.preempt(seq)
                    break
            else:
                num_seqs += 1
                self.block_manager.may_append(seq)
                scheduled_seqs.append(seq)
```

- 检查 `can_append()` 是否需要新块
- 内存不足时 **preempt**（抢占）其他序列
- 调用 `may_append()` 处理块边界

### 4.3 抢占机制

```58:61:nanovllm/engine/scheduler.py
    def preempt(self, seq: Sequence):
        seq.status = SequenceStatus.WAITING
        self.block_manager.deallocate(seq)
        self.waiting.appendleft(seq)
```

当内存不足时，释放某个序列的所有块，将其放回等待队列。

## 5. 整体架构图

```
┌─────────────────────────────────────────────────────────────────┐
│                         LLMEngine                               │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                      Scheduler                           │   │
│  │  ┌─────────────────────────────────────────────────────┐│   │
│  │  │                  BlockManager                        ││   │
│  │  │                                                      ││   │
│  │  │   ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐          ││   │
│  │  │   │Blk 0│ │Blk 1│ │Blk 2│ │Blk 3│ │ ... │  物理块   ││   │
│  │  │   └─────┘ └─────┘ └─────┘ └─────┘ └─────┘          ││   │
│  │  │       ↑       ↑       ↑                             ││   │
│  │  │   ┌───┴───────┴───────┴───┐                         ││   │
│  │  │   │  hash_to_block_id     │  Prefix Cache 索引      ││   │
│  │  │   └───────────────────────┘                         ││   │
│  │  └─────────────────────────────────────────────────────┘│   │
│  │                                                          │   │
│  │  Sequence A: block_table = [0, 1, 2]  ──────────────────┼───┤
│  │  Sequence B: block_table = [0, 1, 3]  (共享前缀块 0,1)  │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

## 6. 总结

| 特性 | 实现方式 |
|------|----------|
| **内存分页** | 固定大小 Block，通过 block_table 映射 |
| **Prefix Caching** | xxhash 哈希链 + hash_to_block_id 索引 |
| **内存共享** | ref_count 引用计数 |
| **动态扩展** | may_append 在 decode 时按需分配 |
| **内存回收** | 抢占机制 + 引用计数归零释放 |

这个设计使得 nano-vllm 能够：
1. **高效利用 GPU 内存**：避免预分配浪费
2. **支持大批量并发**：多序列共享内存
3. **加速重复前缀**：Prefix Caching 避免重复计算

## QA
