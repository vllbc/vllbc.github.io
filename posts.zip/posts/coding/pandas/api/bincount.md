---
title: "bincount"
date: 2022-11-29
lastmod: 2023-06-11
categories: ['pandas', 'api']
tags: ['pandas', 'api', 'bincount']
author: "vllbc"
mathjax: true
markup: pdc

---


![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020221108230222.png)

很简单，就是统计x中的数出现次数，返回结果的最大长度就是x中的最大值+1，idx为对应的数，值为出现的次数，没有出现的为0。
```python3
x = np.array([7, 6, 2, 1, 4]) 
# 索引0出现了0次，索引1出现了1次......索引5出现了0次...... 
np.bincount(x) 
#输出结果为：array([0, 1, 1, 0, 1, 0, 1, 1])
```

weight这个参数也很好理解，x会被它加权，也就是说，如果值n发现在位置i，那么out[n] += weight[i]而不是out[n] += 1。所以weight必须和x等长。

```python3
w = np.array([0.3, 0.5, 0.2, 0.7, 1., -0.6])
# 我们可以看到x中最大的数为4，因此bin的数量为5，那么它的索引值为0->4
x = np.array([2, 1, 3, 4, 4, 3])
# 索引0 -> 0
# 索引1 -> w[1] = 0.5
# 索引2 -> w[0] = 0.3
# 索引3 -> w[2] + w[5] = 0.2 - 0.6 = -0.4
# 索引4 -> w[3] + w[4] = 0.7 + 1 = 1.7
np.bincount(x,  weights=w)
# 因此，输出结果为：array([ 0. ,  0.5,  0.3, -0.4,  1.7])
```

没出现的还是0，出现的要按照出现的地方的weight计算。