---
title: agent RL相关论文
date: 2025-08-08
lastmod: 2025-08-08
categories:
  - Agent
  - reading
tags:
  - Reading
  - Agent
author: vllbc
mathjax: true
markup: pdc
todo: true
---
## tool-use
通过RL提高模型调用工具的能力。
### [Search-R1：Training LLMs to Reason and Leverage Search Engines with Reinforcement Learning](Search-R1：Training%20LLMs%20to%20Reason%20and%20Leverage%20Search%20Engines%20with%20Reinforcement%20Learning.md)

### [WebThinker：Empowering Large Reasoning Models with Deep Research Capability](WebThinker：Empowering%20Large%20Reasoning%20Models%20with%20Deep%20Research%20Capability.md)

### [ZEROSEARCH：Incentivize the Search Capability of LLMs without Searching](ZEROSEARCH：Incentivize%20the%20Search%20Capability%20of%20LLMs%20without%20Searching.md)

### [AGENTIC REINFORCED POLICY OPTIMIZATION](AGENTIC%20REINFORCED%20POLICY%20OPTIMIZATION.md)

### [Search and Refine During Think：Autonomous Retrieval - Augmented Reasoning of LLMs](Search%20and%20Refine%20During%20Think：Autonomous%20Retrieval%20-%20Augmented%20Reasoning%20of%20LLMs.md)

## planning
通过RL提高长程规划能力，一般都会针对信用分配问题进行解决。
### [RLVMR：Reinforcement Learning with Verifiable Meta-Reasoning Rewards for Robust Long-Horizon Agents](../Planning/RLVMR：Reinforcement%20Learning%20with%20Verifiable%20Meta-Reasoning%20Rewards%20for%20Robust%20Long-Horizon%20Agents.md)

### [Group-in-Group Policy Optimization for LLM Agent Training](../Planning/Group-in-Group%20Policy%20Optimization%20for%20LLM%20Agent%20Training.md)

### [Training Long-Context, Multi-Turn Software Engineering Agents with Reinforcement Learning](Training%20Long-Context,%20Multi-Turn%20Software%20Engineering%20Agents%20with%20Reinforcement%20Learning.md)

## 参考

[# 2025年大模型agent rl训练多轮planning技术TORL,ToolRL, RAGEN,OTC,SkyRL-v0, GiGPO,Tool-N1 ,ARTIST, ZeroTIR, GRPO](https://zhuanlan.zhihu.com/p/1902381952998281700)