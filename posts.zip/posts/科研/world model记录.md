参照[WEB AGENTS WITH WORLD MODELS ：LEARNING AND LEVERAGING ENVIRONMENT DYNAMICS IN WEB NAVIGATION](../reading/World-model/WEB%20AGENTS%20WITH%20WORLD%20MODELS%20：LEARNING%20AND%20LEVERAGING%20ENVIRONMENT%20DYNAMICS%20IN%20WEB%20NAVIGATION.md)的思路来设计，创新的地方在于world model和policy共同进化。每一个step二者都更新。利用verl-agent框架，然后world model也使用ray训练，不过是sft，利用vibe coding编写好训练逻辑，但是有一些问题记录下来。
## 问题记录
- 训练很少的step就会直接崩溃。原因是使用了世界模型扩展多个动作，但最后用于训练的还是一开始采样的动作，而不是后面根据分数选择的动作，之前写的代码怎么训都是无用功，还好发现了这个隐藏的很深但又重大的bug。
- world model的训练grad_norm异常大的情况，高达好几千，实在是异常，后面发现是梯度更新的时机不对，原本的实现是先反向传播，然后再除以梯度累积的steps，但这样做是没有意义的，因为反向传播后已经将梯度计算出来了，此时再除就没意义了，因此需要先除以steps然后再反向传播。
- 目前的创新点还是不太够，针对world model的引入可以在memory上做文章，将世界模型每次预测后没有选中的那些action以及预测的observation作为失败的经验，选中的作为成功的经验，然后不断的拓展经验库，再用某种方式检索经验库来指导决策。
- 如何设计奖励？本来使用的value model，但需要训练而且可能reward hacking，后面发现用规则奖励更好，设计了比较简单的规则奖励，但有一个问题是如果world model预测的所有的奖励都是0该如何处理，目前的做法是取原本推理的那个。可以此时再推理一边或者让别的模型介入，问题是如何将其封装为训练样本（需要attention mask等tensor数据）。
- 训练10多个step后就会出现response length骤增的问题，导致vaild action的比例也降低，目前对该问题有个猜测：~~1. world model的训练有问题，world model的训练和policy的训练是否会发生一些数据冲突？二者共用同一个torch进程组，并且world model的grad norm曲线和loss曲线很相似，这个感觉也有问题。~~
去掉world model训练还是有如此问题，猜测为entropy loss的问题，做实验测试
1. bs32，复杂奖励，entropy损失，world model训练，max env step 50, **step 17发生训练崩溃**
2. bs32，复杂奖励，entropy损失，world model不训练，max env step 50, **step17发生崩溃**
3. bs16，简单奖励，去掉entropy损失，world model训练，max env step 40。
	1. 训练到36step开始出现问题，不过vaild_ratio还不是很低，训练没有崩溃，63step出现了最低ratio，
	2. ![image.png](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image20251023140806068.png)
	3. 不知道什么原因熵还是会增加，解决了可以额外出一篇论文了![image.png](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image20251023140906691.png)
	4. entropy_loss、response_length、vaild_action_ratio、clip_ratio这几个指标基本上强相关。
	5. 感觉是奖励设计的有问题，导致脏数据进入了训练？有一个想法是当score所有都是0时，就不训练这个样本，直接mask掉。
	6. 我发现max_steps=50时会在40时胡言乱语，max=40会在30时胡言乱语，那么可以设置成60，到时候测评只用50？这是不太好的解决办法。
4. bs16，修改简单奖励（如果动作不合法就直接为0），去掉entropy损失，world model训练，max env step 50。还是会出现一样的问题，并且这次score也很低，要么是mask的问题，要么是动作不合法的判断逻辑有问题。需要排查。
5. bs16，修改简单奖励（如果没提取合法动作为0，原来为0的为0.1，宽松了一点），去掉entropy损失，world model训练，max env step 50
	1. 还可以排查的点：推理使用hf推理，排查工程问题
	2. 用崩溃的ckpt测试崩溃的数据，看看是kv cache累积的问题还是 脏数据的问题。
	3. 发现了问题所在！就是训练有脏数据，只要推理prompt中存在nothing happens就会胡言乱语，看来问题所在就是奖励设计的问题。
6. bs16，重新设计奖励，去掉专门处理nothing happens，其余同上，训练目前为止一切正常，就是效果不如训练崩溃的效果，感觉还是要改奖励。