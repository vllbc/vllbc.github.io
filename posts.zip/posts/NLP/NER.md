---
title: "NER"
date: 2021-02-06
lastmod: 2023-03-24
categories: ['NLP']
tags: ['NLP', 'NER']
author: "vllbc"
mathjax: true
markup: pdc

---


# NER(命名实体识别)

参考：[https://www.jianshu.com/p/16e1f6a7aaef](https://www.jianshu.com/p/16e1f6a7aaef)

命名实体识别（Named Entity Recognition，简称NER）是信息提取、问答系统、句法分析、机器翻译等应用领域的重要基础工具，在自然语言处理技术走向实用化的过程中占有重要地位。一般来说，命名实体识别的任务就是识别出待处理文本中三大类（实体类、时间类和数字类）、七小类（人名、机构名、地名、时间、日期、货币和百分比）命名实体。
  举个简单的例子，在句子“小明早上8点去学校上课。”中，对其进行命名实体识别，应该能提取信息

> 人名：小明，时间：早上8点，地点：学校。