---
title: "Prompt"
date: 2023-03-02
lastmod: 2023-03-24
categories: ['NLP']
tags: ['NLP', 'Prompt']
author: "vllbc"
mathjax: true
markup: pdc
---


# 参考

[NLP新宠——浅谈Prompt的前世今生 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/399295895)

