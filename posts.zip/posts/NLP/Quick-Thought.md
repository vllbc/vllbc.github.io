---
title: "Quick-Thought"
date: 2022-10-03
lastmod: 2023-03-24
categories: ['NLP']
tags: ['NLP', 'Quick-Thought']
author: "vllbc"
mathjax: true
markup: pdc

---

这是一种句向量的表示方式，即sentence2vec，实际上是对skip thought的改进，