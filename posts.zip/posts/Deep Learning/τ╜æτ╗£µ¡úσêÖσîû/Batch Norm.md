---
title: "Batch Norm"
date: 2023-03-22
lastmod: 2023-03-29
categories: ['Deep Learning', '网络正则化']
tags: ['Deep Learning', '网络正则化', 'Batch Norm']
author: "vllbc"
mathjax: true
markup: pdc
---
