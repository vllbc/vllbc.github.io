---
title: "GRU"
date: 2022-12-04
lastmod: 2023-03-24
categories: ['Deep Learning', '循环神经网络系列']
tags: ['Deep Learning', '循环神经网络系列', 'GRU']
author: "vllbc"
mathjax: true
markup: pdc

---

![image.png](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/20240813224150.png)

其中$r_{t}$为reset门，用于重置上一step的状态。$z_{t}$为update门，用于得到当前step的状态。