---
title: "LSTM"
date: 2021-11-02
lastmod: 2023-03-24
categories: ['Deep Learning', '循环神经网络系列']
tags: ['Deep Learning', '循环神经网络系列', 'LSTM']
author: "vllbc"
mathjax: true
markup: pdc

---


![image.png](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/20240813224213.png)


![image.png](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/20240129215032.png)
