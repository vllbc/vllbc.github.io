---
title: "RNN"
date: 2021-04-21
lastmod: 2023-03-24
categories: ['Deep Learning', '循环神经网络系列']
tags: ['Deep Learning', '循环神经网络系列', 'RNN']
author: "vllbc"
mathjax: true
markup: pdc

---


回看博客，发现深度学习的笔记空荡荡，才发觉一直没有详细得进行笔记，但也感觉确实没有什么可以记录的东西，都是一些网络和模型，具体的trick倒是记录了一些，不过为了博客的美观，还是写一些东西吧，最主要的还是一些小知识。
(MLP就不记录了)

RNN其实很类似于一个自回归模型，用历史观测预测下一个观测，我们可以假设不适用所有的历史预测下一个，而是部分的历史，也就是说序列满足马尔科夫条件，而RNN，即循环神经网络，就符合一阶马尔科夫模型，即当前观测仅仅与前一个的观测有关，模型图如下：

![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020221107230121.png)