---
title: SGD
date: 2025-07-12
lastmod: 2025-07-12
categories:
  - 优化器
tags:
  - 优化器
author: vllbc
mathjax: true
markup: pdc
todo: false
---

作为机器学习的初学者必然会接触梯度下降算法以及 SGD，基本上形式如下：

$$
\theta_t = \theta_{t-1} - \alpha \;g(\theta)
$$
其中 $\alpha$ 为学习率，$g(\theta)$ 为梯度。
