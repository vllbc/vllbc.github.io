---
title: SGD-Momentum
date: 2025-07-12
lastmod: 2025-07-12
categories:
  - ""
  - 优化器
tags:
  - 优化器
author: vllbc
mathjax: true
markup: pdc
todo: false
---

带动量的随机梯度下降方法

它的思路就是计算前面梯度的该变量，每次迭代会考虑前面的计算结果。这样如果在某个维度上波动厉害的特征，会由于“momentum”的影响，而抵消波动的方向（因为波动剧烈的维度每次更新的方向是相反的，momentum 能抵消这种波动）。使得梯度下降更加的平滑，得到更快的收敛效率。而后续提出的 Adagrad，RMSProp 以及结合两者优点的 Adam 算法都考虑了这种“momentum”的思想。

前面求梯度的过程省略了，后面可以这样写：


$$
\begin{align}
& v_t = \beta v_{t-1} + (1-\beta)g_t \\\\
& \theta = \theta - \alpha v_t
\end{align}
$$

其中 $\alpha$ 为学习率，一般的 $\beta$ 为 0.9。V 就是动量。

所以，SGD + Momentum 可以理解为，利用历史权重梯度矩阵 $W_{i} l(i<t)$ 和当前权重梯度矩阵 $W_{t} l$ 的加权平均和，来更新权重矩阵 $W$ 。由于 $\beta \in(0,1)$ ，所以随着 $t$ 的增大和 $i$ 的减小， $\beta^{t-i}$ 会减小，历史权重梯度矩阵 $W_{i} l(i<t)$ 会逐渐减小。通俗来讲，会逐渐遗忘越旧的权重梯度矩阵。

