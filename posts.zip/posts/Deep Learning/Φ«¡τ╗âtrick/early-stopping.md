---
title: "early-stopping"
date: 2023-03-06
lastmod: 2023-03-24
categories: ['Deep Learning', '训练trick']
tags: ['Deep Learning', '训练trick', 'early-stopping']
author: "vllbc"
mathjax: true
markup: pdc


---

## 介绍

早停止（Early Stopping）是 **当达到某种或某些条件时，认为模型已经收敛，结束模型训练，保存现有模型的一种手段**。

如何判断已经收敛？主要看以下几点：
- 验证集上的Loss在模型多次迭代后，没有下降
- 验证集上的Loss开始上升。
这时就可以认为模型没有必要训练了，可以停止了，因为训练下去可能就会发生过拟合，所以早停法是一种防止模型过拟合的方法。

## 代码

```python
import numpy as np
import torch
import os

class EarlyStopping:
    """Early stops the training if validation loss doesn't improve after a given patience."""
    def __init__(self, save_path, patience=7, verbose=False, delta=0):
        """
        Args:
            save_path : 模型保存文件夹
            patience (int): How long to wait after last time validation loss improved.
                            Default: 7
            verbose (bool): If True, prints a message for each validation loss improvement. 
                            Default: False
            delta (float): Minimum change in the monitored quantity to qualify as an improvement.
                            Default: 0
        """
        self.save_path = save_path
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta

    def __call__(self, val_loss, model):

        score = -val_loss

        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
        elif score < self.best_score + self.delta:
            self.counter += 1
            print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
            self.counter = 0

    def save_checkpoint(self, val_loss, model):
        '''Saves model when validation loss decrease.'''
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}).  Saving model ...')
        path = os.path.join(self.save_path, 'best_network.pth')
        torch.save(model.state_dict(), path)	# 这里会存储迄今最优模型的参数
        self.val_loss_min = val_loss


```