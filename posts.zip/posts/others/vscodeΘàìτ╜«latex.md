---
title: "vscode配置latex"
date: 2023-03-21
lastmod: 2023-03-24
categories: ['others']
tags: ['others', 'vscode配置latex']
author: "vllbc"
mathjax: true
markup: pdc
---
早就配置好了，但是之前使用的是tab打开pdf，感觉有点狭窄，于是换成了外部pdf，使用的就是经典的sumatra pdf，具体的配置过程可以看：[https://zhuanlan.zhihu.com/p/142963562](https://zhuanlan.zhihu.com/p/142963562)，但是在配置反向搜索的时候出现了问题，于是查看网上的一些解决方法，一番折腾下终于解决了这个问题，下面是最终方案，记录一下。

首先是使用code.cmd，参考了这个文章：[https://zhuanlan.zhihu.com/p/112108701](https://zhuanlan.zhihu.com/p/112108701)不过直接使用的一个问题就是反向搜索时会弹出cmd窗口，比较烦人，在评论区有人写了脚本解决了这个问题，现在就可以比较完美的进行反向搜索了[https://blog.csdn.net/he_yang_/article/details/129210746?spm=1001.2014.3001.5501](https://blog.csdn.net/he_yang_/article/details/129210746?spm=1001.2014.3001.5501)
