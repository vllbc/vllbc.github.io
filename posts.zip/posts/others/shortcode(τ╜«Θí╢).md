---
title: "shortcode(置顶)"
date: 2023-03-07
lastmod: 2023-03-28
categories: ['others']
tags: ['others', 'shortcode(置顶)']
author: "vllbc"
mathjax: true
markup: pdc
weight: 1
---
贴一下可以玩的shortcode。

## 音乐播放
### 播放列表
夏日口袋专辑：
{{< music auto="https://music.163.com/album?id=73470837&uct2=U2FsdGVkX18gTMY/Tb1+2PmOZr2G/Q7mOdM/mANJ8xY=" >}}


### 播放单曲

最爱的一首（我是紬厨）：
{{< music netease song 1311346841 >}}



## 视频播放
### bilibili
{{< bilibili BV1ptXPYREe7 1>}} 
有多P可以选择集数

## admonition
类型有：note、abstract、info、tip、success、question、warning、failure、danger、bug、example、quote。
{{< admonition type=tip  open=true >}}
一个 **技巧** 横幅
{{< /admonition >}}


## mapbox
{{< mapbox lng=121.485 lat=31.233 zoom=12 >}}

