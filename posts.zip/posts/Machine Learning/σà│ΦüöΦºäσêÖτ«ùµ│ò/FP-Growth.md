---
title: "FP-Growth"
date: 2023-06-10
lastmod: 2023-06-11
categories: ['Machine Learning', '关联规则算法']
tags: ['Machine Learning', '关联规则算法', 'FP-Growth']
author: "vllbc"
mathjax: true
markup: pdc
---
![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611210943.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611210947.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611210955.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611210958.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211006.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211009.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211015.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211020.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211025.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211030.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211034.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211038.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211041.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211045.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211049.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211053.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211056.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211059.png)![](https://cdn.jsdelivr.net/gh/vllbc/img4blog//image/Pasted%20image%2020230611211102.png)