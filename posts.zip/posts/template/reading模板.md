---
title: <% tp.file.title %>
date: <% tp.file.creation_date("YYYY-MM-DD") %>
lastmod: <% tp.file.last_modified_date("YYYY-MM-DD") %>
categories:
  - <% tp.file.folder() %>
  - reading
tags:
  - Reading
  - <% tp.file.folder() %>
author: vllbc
mathjax: true
markup: pdc
todo: true
---
