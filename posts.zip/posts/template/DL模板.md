---
title: <% tp.file.title %>
date: <% tp.file.creation_date("YYYY-MM-DD") %>
lastmod: <% tp.file.last_modified_date("YYYY-MM-DD") %>
Categories:
  - <% tp.file.folder() %>
  - Deep Learning
Tags:
  - Deep Learning
  - <% tp.file.folder() %>
Author: vllbc
Mathjax: true
Markup: pdc
Todo: true
---
