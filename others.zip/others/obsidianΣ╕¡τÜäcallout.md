---
title: obsidian中的callout
date: 2024-03-09
lastmod: 2024-03-09
categories:
  - ""
  - others
tags:
  - others
author: vllbc
mathjax: true
markup: pdc
---
- note
- abstract, summary, tldr
- info, todo
- tip, hint, important
- success, check, done
- question, help, faq
- warning, caution, attention
- failure, fail, missing
- danger, error
- bug
- example
- quote, cite

与本主题的shortcode类似
类型有：note、abstract、info、tip、success、question、warning、failure、danger、bug、example、quote。

{{< admonition type=tip  open=true >}}
一个 **技巧** 横幅
{{< /admonition >}}

# note
>[!note]
>这是一个note

# abstract 
>[!abstract]
>这是一个abstract

# tip
>[!tip]
>这是一个tip

# success

>[!success]
>这是一个success

# question 

>[!question]
>这是一个question

# warning 
>[!warning]
>this is a warning 

# failure 

>[!failure]
>this is a failure 

# danger 
>[!danger ]
>this is a danger 

# bug
>[!bug]
>this is a bug

# example 
>[!example]
>this is a example 

# quote 
>[!quote]
>this is a quote 












